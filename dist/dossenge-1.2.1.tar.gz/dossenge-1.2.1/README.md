# Dossenge - 一个包含很常用功能的Python库


## 项目介绍
Dossenge 是一个为 Python 开发者设计的实用工具库，旨在提供一些常用的功能，帮助开发者快速解决问题。这个库特别适合初学者和需要快速实现某些功能的开发者。

## 主模块

### 方法列表

**引入方法：**
`from Dossenge import Dossenge`或`from Dossenge.Dossenge import *`或`import Dossenge`

**方法列表：**
```python
Dossenge.equal(x, y, roundnum=3) # 判断x与y的差是否小于10**-roundnum（精度影响，可自行设置精度）
Dossenge.chicken_rabbit(head, foot) # 计算鸡兔同笼问题，head个头，foot条腿 返回[(chicken,rabbit)]
Dossenge.fibonacci(number) #计算斐波那契数列的第number项
```

## 字符串处理

**引入Dossenge.string方法：**
`from Dossenge import string`或`from Dossenge.string import *`

**方法列表：**
```python
Dossenge.string.String # 类： 目前没有用处，敬请期待
Dossenge.string.countstr(string) # 以字典形式返回字符串中字符的个数
Dossenge.string.save_add(filepath,string) # 往filepath文件中增加写入string然后返回新的内容
```

## HTTP 请求

**引入方法：** `from Dossenge.http import *`

**方法列表：**
```python
Dossenge.http.header_request(url, **headers) # 发送带有自定义请求头的 HTTP 请求，使用requests库
```

**示例：**

```python
from Dossenge.http import header_request

# 自定义请求头
headers = {
    "User-Agent": "MyApp/1.0",
    "Authorization": "Bearer mytoken",
    "Accept": "application/json"
}

# 发送请求
response = header_request("https://api.example.com/data", **headers)

# 也可
response2 = header_request("https://api.example.com/data", User-Agent="MyApp/1.0")

# 打印响应内容
if response:
    print(response.json())
	
```

## 可数组类

**引入方法：** `from Dossenge.arrayable_class import *`

**方法列表：**
```python
Dossenge.arrayable_class.arrayable(func) # 类装饰器，用于类可数组，使用MyClass[size]
Dossenge.arrayable_class.array(size, typ) # 数组类
    Dossenge.arrayable_class.array(size, typ).print() # 输出一个array(size, ..stdio.char)对象
Dossenge.arrayable_class.arrayable_class_meta() # 可数组类元类
Dossenge.arrayable_class.arrayable_class() # 空基类，可继承
```

**示例：**

```python
from Dossenge.arrayable_class import arrayable_class

class MyClass(arrayable_class):
    pass

arr = MyClass[5]

	
```

## C++ 语法

**引入方法：** `from Dossenge.cppython import *`

**方法列表：**
```python
Dossenge.cppython.printf(text, **formatter) # 没啥用，就是text % formatter
Dossenge.cppython.char() # 类，字符类，也可存UInt8，为arrayable
Dossenge.cppython.Int128() # Int128类，不支持运算，只是二进制
Dossenge.cppython.UInt128() # 无符号版
... # 有Int64还有UInt64，还有32，还有16，还有8，还有UInt1
# 特别注明：Int8就是char
Dossenge.cppython.Struct() # 结构体！
    Dossenge.cppython.Struct().pack() # 打包二进制
    Dossenge.cppython.Struct.unpack() # 类方法，根据二进制解包为对象
Dossenge.cppython.IStream(io) # 输入流
Dossenge.cppython.OStream(io) # 输出流
Dossenge.cppython.cout # 输出到sys.stdout
Dossenge.cppython.cin # 输入从sys.stdin
Dossenge.cppython.cerr # 输出到sys.stderr
Dossenge.cppython.clog # 输出到sys.stderr
Dossenge.cppython.endl # 换行 + flush
Dossenge.cppython.flush # flush刷新
Dossenge.cppython.ws
Dossenge.cppython.Variable # 列表包装引用，应在cin >> var时使用Variable对象
Dossenge.cppython.std # 命名空间，所有均被包装到属性，建议使用std.struct代替Struct
```

**示例：**

```python
from Dossenge.cppython import std

class Point(std.struct):
    x: Float128
	y: Float128
	

point = Point(x=Float128(1.0), y=Float128(1.0)) # 需要转换！
byte = point.pack()
new_point = Point.unpack(byte)

	
```

## 可执行文件
```bash
dossenge equal 0.1+0.2 0.3 5
```
判断x与y的差是否小于10\*\*-5

```bash
dossenge cr head foot
```
解决鸡兔同笼问题
